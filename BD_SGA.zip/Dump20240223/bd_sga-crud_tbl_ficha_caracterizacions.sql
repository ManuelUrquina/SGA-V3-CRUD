-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_sga-crud
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_ficha_caracterizacions`
--

DROP TABLE IF EXISTS `tbl_ficha_caracterizacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_ficha_caracterizacions` (
  `Codigo` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fich_Inicio` date NOT NULL,
  `fich_Fin` date NOT NULL,
  `fich_Etapa` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Codigo_modalidad` bigint unsigned NOT NULL,
  `Codigo_programa` bigint unsigned NOT NULL,
  `Codigo_centro` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `tbl_ficha_caracterizacions_codigo_modalidad_foreign` (`Codigo_modalidad`),
  KEY `tbl_ficha_caracterizacions_codigo_programa_foreign` (`Codigo_programa`),
  KEY `tbl_ficha_caracterizacions_codigo_centro_foreign` (`Codigo_centro`),
  CONSTRAINT `tbl_ficha_caracterizacions_codigo_centro_foreign` FOREIGN KEY (`Codigo_centro`) REFERENCES `tbl_centro_formacions` (`Codigo`),
  CONSTRAINT `tbl_ficha_caracterizacions_codigo_modalidad_foreign` FOREIGN KEY (`Codigo_modalidad`) REFERENCES `tbl_modalidads` (`id`),
  CONSTRAINT `tbl_ficha_caracterizacions_codigo_programa_foreign` FOREIGN KEY (`Codigo_programa`) REFERENCES `tbl_programas` (`prog_codigoPrograma`)
) ENGINE=InnoDB AUTO_INCREMENT=2556232 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_ficha_caracterizacions`
--

LOCK TABLES `tbl_ficha_caracterizacions` WRITE;
/*!40000 ALTER TABLE `tbl_ficha_caracterizacions` DISABLE KEYS */;
INSERT INTO `tbl_ficha_caracterizacions` VALUES (2556229,'2031-01-30','2043-12-12','LI',1,228183,9225,'2024-02-08 15:50:42','2024-02-08 15:50:42'),(2556230,'2022-01-01','2023-01-01','Lectiva',1,228183,9225,'2024-02-22 11:20:00','2024-02-22 11:20:00'),(2556231,'2023-01-01','2024-01-01','Productiva',1,228184,9225,'2024-02-22 11:39:59','2024-02-22 11:39:59');
/*!40000 ALTER TABLE `tbl_ficha_caracterizacions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-23  9:06:07
