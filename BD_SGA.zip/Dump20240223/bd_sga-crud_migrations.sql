-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_sga-crud
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (436,'2014_10_12_000000_create_users_table',1),(437,'2014_10_12_100000_create_password_resets_table',1),(438,'2019_08_19_000000_create_failed_jobs_table',1),(439,'2019_12_14_000001_create_personal_access_tokens_table',1),(440,'2023_06_17_041300_create_tbl_nivel_formacions_table',1),(441,'2023_06_17_041553_create_tbl_programas_table',1),(442,'2023_06_17_042437_create_tbl_competencias_table',1),(443,'2023_06_17_043451_create_tbl_perfil_instructors_table',1),(444,'2023_06_17_043833_create_tbl_modalidads_table',1),(445,'2023_06_17_043958_create_tbl_regionales_table',1),(446,'2023_06_17_044137_create_tbl_centro_formacions_table',1),(447,'2023_06_17_045219_create_tbl_tipo_ambientes_table',1),(448,'2023_06_17_045359_create_tbl_estado_ambientes_table',1),(449,'2023_06_17_045603_create_tbl_ambientes_table',1),(450,'2023_06_17_046020_create_tbl_ficha_caracterizacions_table',1),(451,'2023_06_17_050200_create_tbl_redes_table',1),(452,'2023_06_17_050309_create_tbl_especialidades_table',1),(453,'2023_06_17_050549_create_tbl_vigencias_table',1),(454,'2023_06_17_051208_create_tbl_instructores_table',1),(455,'2023_06_17_052058_create_tbl_resultado_aprendizajes_table',1),(456,'2023_06_17_052434_create_tbl_concepto_principios_table',1),(457,'2023_06_17_053334_create_tbl_procesos_table',1),(458,'2023_06_17_053438_create_tbl_criterio_de_evaluacions_table',1),(459,'2023_06_17_053523_create_tbl_material_requeridos_table',1),(460,'2023_06_17_053629_create_tbl_perfil_tecnico_del_instructors_table',1),(461,'2023_06_17_054017_create_tbl_eventos_table',1),(462,'2023_06_26_202806_create_eventos_table',1),(463,'2023_07_15_011623_create_permission_tables',1),(464,'2023_07_15_014256_create_roles',1),(465,'2023_08_30_160344_create_archivos_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-23  9:06:06
