-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: bd_sga-crud
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_resultado_aprendizajes`
--

DROP TABLE IF EXISTS `tbl_resultado_aprendizajes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_resultado_aprendizajes` (
  `Codigo` bigint unsigned NOT NULL AUTO_INCREMENT,
  `resul_Denominacion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Codigo_competencias` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `tbl_resultado_aprendizajes_codigo_competencias_foreign` (`Codigo_competencias`),
  CONSTRAINT `tbl_resultado_aprendizajes_codigo_competencias_foreign` FOREIGN KEY (`Codigo_competencias`) REFERENCES `tbl_competencias` (`comp_codigoCompetencia`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_resultado_aprendizajes`
--

LOCK TABLES `tbl_resultado_aprendizajes` WRITE;
/*!40000 ALTER TABLE `tbl_resultado_aprendizajes` DISABLE KEYS */;
INSERT INTO `tbl_resultado_aprendizajes` VALUES (1,'test',12,'2024-02-08 14:48:17','2024-02-08 14:48:17'),(2,'test',12,'2024-02-08 14:49:55','2024-02-08 14:49:55'),(3,'test',12,'2024-02-08 14:52:01','2024-02-08 14:52:01'),(6,'test',12,'2024-02-09 12:11:45','2024-02-09 12:11:45'),(7,'test',12,'2024-02-09 12:21:40','2024-02-09 12:21:40'),(8,'test',12,'2024-02-09 12:23:49','2024-02-09 12:23:49'),(9,'test',12,'2024-02-09 12:25:44','2024-02-09 12:25:44'),(10,'test',12,'2024-02-09 12:27:18','2024-02-09 12:27:18');
/*!40000 ALTER TABLE `tbl_resultado_aprendizajes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-23  9:06:08
